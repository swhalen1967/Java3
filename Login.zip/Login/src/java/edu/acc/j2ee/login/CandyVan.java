package edu.acc.j2ee.login;

public class CandyVan {
    private static final String[] TREASURES = {"gold bullion", "lollypop", 
        "box of Lego", "pack of Starburst", "shiny penny", "rusty sword", "jug of XXX", 
        "rainbow unicorn horn", "silver star", "sparkly gemstone", 
        "purple people eater", "chunk of kryptonite", "lump of coal",
        "smelly sock", "perfect diamond", "pumpkin", "a chocolate pudding",
        "shiny button", "bran muffin", "frosty cold beer", "ham sandwich",
        "suit of armor", "black felt fedora", "puddle of green goo"};
    
    public String getTreasure() {
        return TREASURES[(int) (Math.random() * TREASURES.length)];
    }
}
